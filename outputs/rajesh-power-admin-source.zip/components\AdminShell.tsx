"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Bell,
  BookOpen,
  Boxes,
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Clock3,
  Command,
  CreditCard,
  Download,
  FileBarChart,
  FileText,
  Gauge,
  Headphones,
  Home,
  IndianRupee,
  LayoutDashboard,
  LogOut,
  Mail,
  Menu,
  MessageSquareText,
  MoreHorizontal,
  PackageCheck,
  PlugZap,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  TrendingUp,
  UserRound,
  Users,
  Wrench,
  X,
  Zap,
  type LucideIcon,
} from "lucide-react";

type NavItem = { label: string; icon: LucideIcon; badge?: string };

const navigation: { title: string; items: NavItem[] }[] = [
  {
    title: "Workspace",
    items: [
      { label: "Overview", icon: LayoutDashboard },
      { label: "Work Orders", icon: BriefcaseBusiness, badge: "12" },
      { label: "Customers", icon: Users },
      { label: "Assets", icon: Boxes },
    ],
  },
  {
    title: "Management",
    items: [
      { label: "Field Teams", icon: Wrench },
      { label: "Billing", icon: CreditCard },
      { label: "Reports", icon: FileBarChart },
      { label: "Documents", icon: FileText },
    ],
  },
  {
    title: "System",
    items: [
      { label: "Support", icon: Headphones },
      { label: "Settings", icon: Settings },
    ],
  },
];

const horizontalMenus = [
  {
    label: "Operations",
    icon: PlugZap,
    items: ["Service requests", "Preventive maintenance", "Site inspections"],
  },
  {
    label: "Commerce",
    icon: IndianRupee,
    items: ["Invoices & payments", "Quotations", "Vendors & purchase"],
  },
  {
    label: "Intelligence",
    icon: Gauge,
    items: ["Performance reports", "Energy analytics", "Audit activity"],
  },
];

const stats = [
  {
    label: "Active work orders",
    value: "148",
    delta: "12.4%",
    direction: "up",
    note: "vs. last month",
    icon: BriefcaseBusiness,
    tone: "blue",
  },
  {
    label: "Monthly revenue",
    value: "₹42.8L",
    delta: "8.2%",
    direction: "up",
    note: "vs. last month",
    icon: IndianRupee,
    tone: "red",
  },
  {
    label: "Service efficiency",
    value: "94.6%",
    delta: "2.1%",
    direction: "up",
    note: "vs. last month",
    icon: Gauge,
    tone: "green",
  },
  {
    label: "Pending approvals",
    value: "18",
    delta: "3.8%",
    direction: "down",
    note: "vs. last week",
    icon: Clock3,
    tone: "amber",
  },
];

const workOrders = [
  { id: "WO-2847", client: "Apex Industrial Park", service: "Transformer maintenance", date: "27 Jun, 10:30 AM", status: "In progress", avatar: "AI" },
  { id: "WO-2846", client: "Sarthak Textiles", service: "HT panel inspection", date: "27 Jun, 09:15 AM", status: "Scheduled", avatar: "ST" },
  { id: "WO-2845", client: "Meridian Heights", service: "Power audit & testing", date: "26 Jun, 04:40 PM", status: "Completed", avatar: "MH" },
  { id: "WO-2844", client: "Orbit Healthcare", service: "Emergency breakdown", date: "26 Jun, 02:20 PM", status: "Attention", avatar: "OH" },
  { id: "WO-2843", client: "Nova Foods Pvt. Ltd.", service: "DG synchronization", date: "26 Jun, 11:50 AM", status: "Completed", avatar: "NF" },
];

const activity = [
  { icon: CheckCircle2, tone: "green", title: "Work order completed", text: "WO-2845 · Meridian Heights", time: "8 min ago" },
  { icon: CreditCard, tone: "blue", title: "Payment received", text: "₹3,84,500 · Invoice #RP-9812", time: "24 min ago" },
  { icon: UserRound, tone: "purple", title: "Technician assigned", text: "Rohan K. → Apex Industrial Park", time: "1 hr ago" },
  { icon: AlertTriangle, tone: "amber", title: "SLA attention required", text: "WO-2844 · Orbit Healthcare", time: "2 hrs ago" },
];

export default function AdminShell() {
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [activeNav, setActiveNav] = useState("Overview");
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [period, setPeriod] = useState("This month");

  const today = useMemo(
    () =>
      new Intl.DateTimeFormat("en-IN", {
        weekday: "long",
        day: "numeric",
        month: "long",
      }).format(new Date()),
    []
  );

  function chooseNav(label: string) {
    setActiveNav(label);
    setSidebarOpen(false);
  }

  return (
    <div className={`admin-layout ${collapsed ? "sidebar-collapsed" : ""}`}>
      {sidebarOpen && <button className="mobile-overlay" onClick={() => setSidebarOpen(false)} aria-label="Close menu" />}

      <aside className={`sidebar ${sidebarOpen ? "mobile-open" : ""}`}>
        <div className="sidebar-brand">
          <Image
            src="/rajesh-power-logo.png"
            alt="Rajesh Power Services"
            width={190}
            height={80}
            className="sidebar-logo"
            priority
          />
          <div className="brand-mini"><Zap size={22} fill="currentColor" /></div>
          <button className="mobile-sidebar-close" onClick={() => setSidebarOpen(false)} aria-label="Close menu"><X size={20} /></button>
        </div>

        <nav className="side-nav">
          {navigation.map((section) => (
            <div className="nav-section" key={section.title}>
              <span className="nav-title">{section.title}</span>
              {section.items.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    className={`nav-item ${activeNav === item.label ? "active" : ""}`}
                    key={item.label}
                    onClick={() => chooseNav(item.label)}
                    title={collapsed ? item.label : undefined}
                  >
                    <Icon size={19} strokeWidth={1.9} />
                    <span>{item.label}</span>
                    {item.badge && <em>{item.badge}</em>}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="sidebar-card">
          <div className="sidebar-card-icon"><Sparkles size={18} /></div>
          <strong>Need a hand?</strong>
          <p>Our support team is ready to help.</p>
          <button><MessageSquareText size={15} /> Chat with support</button>
        </div>

        <button className="collapse-button" onClick={() => setCollapsed((value) => !value)}>
          {collapsed ? <ChevronRight size={17} /> : <ChevronLeft size={17} />}
          <span>Collapse sidebar</span>
        </button>
      </aside>

      <div className="admin-main">
        <header className="topbar">
          <div className="topbar-left">
            <button className="menu-trigger" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu size={21} /></button>
            <button className="global-search" onClick={() => setSearchOpen(true)}>
              <Search size={18} />
              <span>Search anything...</span>
              <kbd><Command size={12} /> K</kbd>
            </button>
          </div>

          <div className="topbar-actions">
            <button className="icon-button help-button" aria-label="Help"><CircleHelp size={20} /></button>
            <div className="popover-wrap">
              <button
                className={`icon-button ${notificationsOpen ? "selected" : ""}`}
                onClick={() => {
                  setNotificationsOpen((value) => !value);
                  setProfileOpen(false);
                }}
                aria-label="Notifications"
              >
                <Bell size={20} />
                <span className="notification-dot" />
              </button>
              {notificationsOpen && (
                <div className="popover notification-popover">
                  <div className="popover-head"><strong>Notifications</strong><button>Mark all read</button></div>
                  <div className="notification-item unread">
                    <span className="notice-icon warning"><AlertTriangle size={17} /></span>
                    <div><strong>SLA needs attention</strong><p>Work order WO-2844 is nearing its limit.</p><small>12 minutes ago</small></div>
                  </div>
                  <div className="notification-item">
                    <span className="notice-icon success"><Check size={17} /></span>
                    <div><strong>Payment confirmed</strong><p>Invoice RP-9812 has been settled.</p><small>24 minutes ago</small></div>
                  </div>
                  <button className="popover-footer">View all notifications <ArrowRight size={15} /></button>
                </div>
              )}
            </div>

            <span className="topbar-divider" />

            <div className="popover-wrap">
              <button
                className="profile-trigger"
                onClick={() => {
                  setProfileOpen((value) => !value);
                  setNotificationsOpen(false);
                }}
              >
                <span className="profile-avatar">RP</span>
                <span className="profile-copy"><strong>Rajesh Patel</strong><small>Super Admin</small></span>
                <ChevronDown size={16} />
              </button>
              {profileOpen && (
                <div className="popover profile-popover">
                  <div className="profile-popover-head"><span className="profile-avatar large">RP</span><div><strong>Rajesh Patel</strong><small>rajesh@rajeshpower.com</small></div></div>
                  <button><UserRound size={17} /> My profile</button>
                  <button><Settings size={17} /> Account settings</button>
                  <button className="danger" onClick={() => router.push("/")}><LogOut size={17} /> Sign out</button>
                </div>
              )}
            </div>
          </div>
        </header>

        <nav className="horizontal-nav">
          <span className="horizontal-label">Quick access</span>
          {horizontalMenus.map((menu) => {
            const Icon = menu.icon;
            return (
              <div className="horizontal-menu-wrap" key={menu.label}>
                <button
                  className={activeMenu === menu.label ? "active" : ""}
                  onClick={() => setActiveMenu(activeMenu === menu.label ? null : menu.label)}
                >
                  <Icon size={16} /> {menu.label} <ChevronDown size={14} />
                </button>
                {activeMenu === menu.label && (
                  <div className="horizontal-dropdown">
                    <span>{menu.label}</span>
                    {menu.items.map((item) => <button key={item} onClick={() => { setActiveNav(item); setActiveMenu(null); }}>{item}<ChevronRight size={14} /></button>)}
                  </div>
                )}
              </div>
            );
          })}
          <span className="nav-spacer" />
          <button className="quick-link"><BookOpen size={16} /> Knowledge base</button>
        </nav>

        <main className="dashboard-content">
          <div className="page-heading">
            <div>
              <span className="mobile-date">{today}</span>
              <h1>{activeNav === "Overview" ? "Good morning, Rajesh" : activeNav}</h1>
              <p>{activeNav === "Overview" ? "Here’s what’s happening across your operations today." : `Manage and review ${activeNav.toLowerCase()} across Rajesh Power.`}</p>
            </div>
            <div className="heading-actions">
              <button className="secondary-button"><Download size={17} /> Export report</button>
              <button className="primary-button"><Plus size={18} /> New work order</button>
            </div>
          </div>

          {activeNav !== "Overview" && (
            <section className="module-placeholder">
              <div className="module-placeholder-icon"><PackageCheck size={30} /></div>
              <span className="eyebrow">RAJESH POWER ADMIN</span>
              <h2>{activeNav} workspace</h2>
              <p>This module is ready for your live data connection. The navigation, states, and responsive workspace shell are fully in place.</p>
              <button className="primary-button" onClick={() => setActiveNav("Overview")}><Home size={17} /> Return to overview</button>
            </section>
          )}

          {activeNav === "Overview" && (
            <>
              <section className="stats-grid">
                {stats.map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <article className="stat-card" key={stat.label}>
                      <div className="stat-top">
                        <span className={`stat-icon ${stat.tone}`}><Icon size={20} /></span>
                        <button aria-label={`More options for ${stat.label}`}><MoreHorizontal size={20} /></button>
                      </div>
                      <span className="stat-label">{stat.label}</span>
                      <div className="stat-value-row">
                        <strong>{stat.value}</strong>
                        <span className={stat.direction === "down" ? "negative" : "positive"}>
                          {stat.direction === "down" ? <ArrowDownRight size={14} /> : <ArrowUpRight size={14} />}
                          {stat.delta}
                        </span>
                      </div>
                      <small>{stat.note}</small>
                    </article>
                  );
                })}
              </section>

              <section className="dashboard-grid">
                <article className="panel revenue-panel">
                  <div className="panel-header">
                    <div><h2>Revenue overview</h2><p>Income performance across the year</p></div>
                    <select value={period} onChange={(event) => setPeriod(event.target.value)}>
                      <option>This month</option>
                      <option>Last 3 months</option>
                      <option>This year</option>
                    </select>
                  </div>
                  <div className="chart-summary">
                    <div><span>Total revenue</span><strong>₹42,84,750</strong></div>
                    <span className="positive"><TrendingUp size={15} /> 8.2% from last month</span>
                  </div>
                  <RevenueChart />
                  <div className="chart-legend"><span><i className="legend-current" /> Current period</span><span><i className="legend-previous" /> Previous period</span></div>
                </article>

                <article className="panel performance-panel">
                  <div className="panel-header">
                    <div><h2>Service performance</h2><p>Monthly completion score</p></div>
                    <button className="panel-action"><MoreHorizontal size={19} /></button>
                  </div>
                  <div className="gauge-wrap">
                    <svg viewBox="0 0 200 118" role="img" aria-label="94.6 percent service performance">
                      <path className="gauge-bg" d="M 25 100 A 75 75 0 0 1 175 100" />
                      <path className="gauge-value" d="M 25 100 A 75 75 0 0 1 175 100" />
                    </svg>
                    <div className="gauge-number"><strong>94.6%</strong><span>Excellent</span></div>
                  </div>
                  <div className="performance-list">
                    <div><span><i className="dot blue" /> On-time completion</span><strong>96%</strong></div>
                    <div><span><i className="dot red" /> First-time resolution</span><strong>92%</strong></div>
                    <div><span><i className="dot green" /> Customer satisfaction</span><strong>4.8/5</strong></div>
                  </div>
                </article>
              </section>

              <section className="dashboard-grid lower-grid">
                <article className="panel work-panel">
                  <div className="panel-header">
                    <div><h2>Recent work orders</h2><p>Latest service activity across all locations</p></div>
                    <div className="table-actions">
                      <button><SlidersHorizontal size={16} /> Filter</button>
                      <button className="view-all">View all <ArrowRight size={15} /></button>
                    </div>
                  </div>
                  <div className="table-scroll">
                    <table>
                      <thead><tr><th>Order</th><th>Customer & service</th><th>Scheduled</th><th>Status</th><th /></tr></thead>
                      <tbody>
                        {workOrders.map((order, index) => (
                          <tr key={order.id}>
                            <td><strong>{order.id}</strong></td>
                            <td>
                              <div className="customer-cell">
                                <span className={`customer-avatar tone-${index % 4}`}>{order.avatar}</span>
                                <div><strong>{order.client}</strong><small>{order.service}</small></div>
                              </div>
                            </td>
                            <td>{order.date}</td>
                            <td><span className={`status ${order.status.toLowerCase().replace(" ", "-")}`}>{order.status}</span></td>
                            <td><button className="row-action"><ChevronRight size={17} /></button></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </article>

                <article className="panel activity-panel">
                  <div className="panel-header">
                    <div><h2>Live activity</h2><p>Updates from your team</p></div>
                    <span className="live-label"><i /> Live</span>
                  </div>
                  <div className="activity-list">
                    {activity.map((item) => {
                      const Icon = item.icon;
                      return (
                        <div className="activity-item" key={item.title}>
                          <span className={`activity-icon ${item.tone}`}><Icon size={17} /></span>
                          <div><strong>{item.title}</strong><p>{item.text}</p><small>{item.time}</small></div>
                        </div>
                      );
                    })}
                  </div>
                  <button className="activity-button">See complete activity <ArrowRight size={15} /></button>
                </article>
              </section>
            </>
          )}
        </main>

        <nav className="mobile-bottom-nav">
          {[
            { label: "Home", icon: Home, target: "Overview" },
            { label: "Orders", icon: BriefcaseBusiness, target: "Work Orders" },
            { label: "New", icon: Plus, target: "New work order" },
            { label: "Alerts", icon: Bell, target: "Alerts" },
            { label: "Profile", icon: UserRound, target: "Profile" },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                className={`${activeNav === item.target ? "active" : ""} ${item.label === "New" ? "new-action" : ""}`}
                key={item.label}
                onClick={() => chooseNav(item.target)}
              >
                <span><Icon size={item.label === "New" ? 22 : 19} /></span>
                <small>{item.label}</small>
              </button>
            );
          })}
        </nav>
      </div>

      {searchOpen && (
        <div className="search-modal-backdrop" onClick={() => setSearchOpen(false)}>
          <div className="search-modal" onClick={(event) => event.stopPropagation()}>
            <div className="search-modal-input"><Search size={20} /><input autoFocus placeholder="Search work orders, customers, invoices..." /><kbd>ESC</kbd></div>
            <div className="search-suggestions">
              <span>QUICK ACTIONS</span>
              <button onClick={() => setSearchOpen(false)}><BriefcaseBusiness size={18} /><div><strong>Create work order</strong><small>Start a new service request</small></div><ChevronRight size={16} /></button>
              <button onClick={() => setSearchOpen(false)}><Users size={18} /><div><strong>Find customer</strong><small>Search customer directory</small></div><ChevronRight size={16} /></button>
              <button onClick={() => setSearchOpen(false)}><FileBarChart size={18} /><div><strong>Open reports</strong><small>View performance analytics</small></div><ChevronRight size={16} /></button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function RevenueChart() {
  return (
    <div className="chart-area">
      <div className="chart-y-labels"><span>50L</span><span>40L</span><span>30L</span><span>20L</span><span>10L</span><span>0</span></div>
      <svg viewBox="0 0 700 220" preserveAspectRatio="none" role="img" aria-label="Revenue trend chart">
        <defs>
          <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1261d8" stopOpacity=".24" />
            <stop offset="100%" stopColor="#1261d8" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[20, 60, 100, 140, 180, 219].map((y) => <line key={y} x1="0" x2="700" y1={y} y2={y} className="chart-grid-line" />)}
        <path className="chart-previous" d="M0,178 C55,160 70,185 120,155 S205,125 245,140 S330,150 370,112 S450,90 490,104 S575,82 610,78 S675,64 700,72" />
        <path className="chart-area-fill" d="M0,187 C50,178 75,150 120,162 S198,128 245,120 S325,138 370,92 S450,68 490,78 S570,48 610,57 S672,30 700,39 L700,220 L0,220 Z" />
        <path className="chart-current" d="M0,187 C50,178 75,150 120,162 S198,128 245,120 S325,138 370,92 S450,68 490,78 S570,48 610,57 S672,30 700,39" />
        <circle cx="700" cy="39" r="5" className="chart-dot" />
      </svg>
      <div className="chart-x-labels">{["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"].map((month) => <span key={month}>{month}</span>)}</div>
    </div>
  );
}
